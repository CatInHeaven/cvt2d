## Build

Use makefile to build. Requires Emscripten framework to build (and Node.JS to run UglifyJS).

WORK IN PROGRESS
