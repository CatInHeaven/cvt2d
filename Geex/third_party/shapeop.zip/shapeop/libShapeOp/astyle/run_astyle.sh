astyle --options=libShapeOp.astyle ../src/*.h ../src/*.cpp ../api/*.h ../api/*.cpp
